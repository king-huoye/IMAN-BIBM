from .modmis_datamodule import MODMISDataset

_datamodules = {
    "modmis": MODMISDataset,
}
